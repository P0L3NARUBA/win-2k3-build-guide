/*++

Copyright (c) 1999  Microsoft Corporation

Module Name:

    halsym.c

--*/

#include "processor.h"

FDO_DATA fdodata;

int cdecl main() { 
    return 0; 
}

